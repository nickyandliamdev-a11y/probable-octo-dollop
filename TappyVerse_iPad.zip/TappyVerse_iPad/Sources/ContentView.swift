import SwiftUI
import AVFoundation

struct ContentView: View {
    @StateObject private var vm = GameViewModel()
    @State private var animatePop = false

    var body: some View {
        GeometryReader { geo in
            ZStack {
                // Background
                LinearGradient(gradient: Gradient(colors: [Color("BgStart"), Color("BgEnd")]), startPoint: .topLeading, endPoint: .bottomTrailing)
                    .ignoresSafeArea()

                VStack(spacing: 24) {
                    Text("TappyVerse")
                        .font(.largeTitle)
                        .bold()
                        .padding(.top, 30)

                    HStack(spacing: 20) {
                        VStack(alignment: .leading) {
                            Text("Coins")
                                .font(.headline)
                            Text("\(vm.coins)")
                                .font(.title)
                                .bold()
                        }
                        Spacer()
                        VStack(alignment: .leading) {
                            Text("Per Tap")
                                .font(.headline)
                            Text("\(vm.coinsPerTap)")
                                .font(.title2)
                                .bold()
                        }
                    }
                    .padding(.horizontal, 40)

                    Spacer()

                    // Big tappable area
                    ZStack {
                        Circle()
                            .fill(LinearGradient(gradient: Gradient(colors: [Color("ButtonStart"), Color("ButtonEnd")]), startPoint: .top, endPoint: .bottom))
                            .frame(width: min(geo.size.width, geo.size.height) * 0.5, height: min(geo.size.width, geo.size.height) * 0.5)
                            .shadow(radius: 10)
                            .scaleEffect(animatePop ? 1.05 : 1.0)
                            .animation(.spring(response: 0.3, dampingFraction: 0.6), value: animatePop)

                        VStack {
                            Image(systemName: "hand.tap.fill")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 80, height: 80)
                                .foregroundStyle(.white)
                            Text("Tap me!")
                                .font(.title2)
                                .bold()
                                .foregroundColor(.white)
                        }
                    }
                    .onTapGesture {
                        vm.registerTap()
                        animatePop = true
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.12) {
                            animatePop = false
                        }
                    }

                    Spacer()

                    // Upgrade button
                    Button(action: {
                        vm.buyUpgrade()
                    }) {
                        HStack {
                            Text("Upgrade (+1 per tap)")
                                .bold()
                            Spacer()
                            Text(vm.upgradeCostString)
                                .bold()
                        }
                        .padding()
                        .background(RoundedRectangle(cornerRadius: 12).fill(Color.white.opacity(0.15)))
                        .padding(.horizontal, 40)
                    }
                    .disabled(!vm.canAffordUpgrade)
                    .opacity(vm.canAffordUpgrade ? 1.0 : 0.6)

                    Spacer(minLength: 20)
                }
                .foregroundColor(.white)
            }
        }
        .onAppear {
            vm.prepareSounds()
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

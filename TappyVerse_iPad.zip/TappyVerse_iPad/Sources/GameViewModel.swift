import Foundation
import AVFoundation

@MainActor class GameViewModel: ObservableObject {
    @Published var coins: Int = 0
    @Published var coinsPerTap: Int = 1

    private var tapPlayer: AVAudioPlayer?
    private var coinPlayer: AVAudioPlayer?

    var upgradeCost: Int {
        // simple exponential-ish cost
        return 10 * (coinsPerTap)
    }

    var upgradeCostString: String {
        return "\(upgradeCost)"
    }

    var canAffordUpgrade: Bool {
        coins >= upgradeCost
    }

    func registerTap() {
        coins += coinsPerTap
        playTap()
        // short coin jingle if big gain (example)
        if coinsPerTap >= 5 {
            playCoin()
        }
    }

    func buyUpgrade() {
        guard canAffordUpgrade else { return }
        coins -= upgradeCost
        coinsPerTap += 1
        playCoin()
    }

    // MARK: - Sounds
    func prepareSounds() {
        tapPlayer = loadPlayer(forResource: "tap", ofType: "wav")
        coinPlayer = loadPlayer(forResource: "coin", ofType: "wav")
    }

    private func loadPlayer(forResource name: String, ofType type: String) -> AVAudioPlayer? {
        guard let url = Bundle.main.url(forResource: name, withExtension: type) else {
            print("Missing sound: \(name).\(type)")
            return nil
        }
        do {
            let player = try AVAudioPlayer(contentsOf: url)
            player.prepareToPlay()
            return player
        } catch {
            print("Error loading sound: \(error)")
            return nil
        }
    }

    private func playTap() {
        tapPlayer?.currentTime = 0
        tapPlayer?.play()
    }

    private func playCoin() {
        coinPlayer?.currentTime = 0
        coinPlayer?.play()
    }
}
